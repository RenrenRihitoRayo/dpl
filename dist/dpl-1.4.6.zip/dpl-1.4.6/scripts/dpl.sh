#!/bin/bash

# A proxy to the actual script

python3 ~/dpl/dpl.py "$@"
