#!/bin/bash

# Run it directly.

python3 ~/dpl/dpl.py run $@
