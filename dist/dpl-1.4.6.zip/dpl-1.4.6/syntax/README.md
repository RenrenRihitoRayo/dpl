# This is where future syntax files will go.

Currently Supported Applications:
* Sublime Text
* Vim (todo)
