test = {}

test.some_var = 148

function test.some_func()
    return 148
end

return test