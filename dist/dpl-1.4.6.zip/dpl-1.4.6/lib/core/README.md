# Todo
- Add more features
- Add a automated way of converting files version to version
- Make C integration possible
- Logging
